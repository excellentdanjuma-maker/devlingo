# Devlingo

Devlingo is a polished coding quiz experience for learners who want a modern, motivating practice flow.

## Highlights
- Modern onboarding flow
- Google and Apple sign-in support through Firebase Auth
- Profile page with XP, achievements, and streaks
- Settings page for notifications, sound, and theme preference
- Existing quiz gameplay preserved

## Setup
1. Copy .env.example to .env
2. Fill in your Firebase web config values
3. Run npm install
4. Run npm run dev

## Production notes
- Configure Firebase Authentication providers for Google and Apple
- Add your app’s signing credentials for Play Store and App Store release
- Replace placeholder icons in public/manifest.json with branded assets before shipping
