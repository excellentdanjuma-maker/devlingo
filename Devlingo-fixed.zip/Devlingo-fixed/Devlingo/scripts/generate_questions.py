import json
from pathlib import Path

out_path = Path(__file__).resolve().parent.parent / 'src' / 'data' / 'questions.js'

questions = []

python_questions = [
    {
        'type': 'guess-output',
        'examples': [
            {'code': 'print(2 + 3 * 4)', 'answer': '14', 'options': ['14', '20', '18', '24'], 'explanation': 'Multiplication happens before addition.'},
            {'code': 'print(10 // 3)', 'answer': '3', 'options': ['3', '3.33', '4', '0'], 'explanation': 'Integer floor division truncates toward negative infinity.'},
            {'code': 'print("ab" * 3)', 'answer': 'ababab', 'options': ['ababab', 'ab3', 'error', '"ab" "ab" "ab"'], 'explanation': 'String repetition multiplies the string value.'},
            {'code': 'print(sum([1, 2, 3]))', 'answer': '6', 'options': ['6', '5', '9', 'None'], 'explanation': 'sum adds all numbers in the list.'},
            {'code': 'print(len("code"))', 'answer': '4', 'options': ['4', '3', '5', 'error'], 'explanation': 'len returns the number of characters.'},
        ],
    },
    {
        'type': 'find-bug',
        'examples': [
            {'code': 'def greet(name):\n    message = "Hello " + name\n    return message\n\nprint(greet())', 'answer': 'TypeError is raised', 'options': ['TypeError is raised', 'Prints Hello None', 'Prints Hello', 'NameError is raised'], 'explanation': 'greet() needs an argument.'},
            {'code': 'numbers = [1, 2, 3]\nfor i in range(len(numbers)):\n    numbers.pop(i)\nprint(numbers)', 'answer': 'List is shorter than expected', 'options': ['List is shorter than expected', 'List stays unchanged', 'IndexError is raised', 'It prints [1,2,3]'], 'explanation': 'Removing items while iterating changes the list length and indexes.'},
            {'code': 'data = {"a": 1, "b": 2}\nfor key in data:\n    if key == "a":\n        del data[key]\nprint(data)', 'answer': 'RuntimeError is raised', 'options': ['RuntimeError is raised', 'Prints {"b": 2}', 'Prints {}', 'Prints {"a":1}'], 'explanation': 'Mutating a dict while iterating it raises a runtime error.'},
        ],
    },
    {
        'type': 'fill-blank',
        'examples': [
            {'code': 'numbers = [1, 2, 3, 4]\nevens = [x for x in numbers if ___]\n', 'answer': 'x % 2 == 0', 'options': ['x % 2 == 0', 'x == 0', 'x < 2', 'x // 2'], 'explanation': 'Use a modulus check to keep even values.'},
            {'code': 'name = "Dev"\nmessage = f"Hello, {___}!"\n', 'answer': 'name', 'options': ['name', '"name"', 'Name', '{name}'], 'explanation': 'In an f-string, variable names are inserted directly inside braces.'},
        ],
    },
    {
        'type': 'multiple-choice',
        'examples': [
            {'code': 'Python dictionaries preserve insertion order.', 'answer': 'True', 'options': ['True', 'False', 'Only in Python 2', 'Only with OrderedDict'], 'explanation': 'As of Python 3.7, dict preserves insertion order by language guarantee.'},
            {'code': 'A tuple is mutable.', 'answer': 'False', 'options': ['False', 'True', 'Only if it contains lists', 'Only in Python 3.10+'], 'explanation': 'Tuples are immutable containers.'},
        ],
    },
]

js_questions = [
    {
        'type': 'guess-output',
        'examples': [
            {'code': 'console.log(2 + 3 * 4);', 'answer': '14', 'options': ['14', '20', '18', '24'], 'explanation': 'Multiplication has higher precedence than addition.'},
            {'code': 'console.log("hi" + " " + "there");', 'answer': 'hi there', 'options': ['hi there', 'hi', 'there', 'error'], 'explanation': 'String concatenation joins the pieces.'},
            {'code': 'console.log(typeof undefined);', 'answer': 'undefined', 'options': ['undefined', 'null', 'object', 'string'], 'explanation': 'typeof undefined returns the string "undefined".'},
            {'code': 'console.log(Boolean(""));', 'answer': 'false', 'options': ['false', 'true', 'true-ish', 'undefined'], 'explanation': 'An empty string is falsy in JavaScript.'},
        ],
    },
    {
        'type': 'find-bug',
        'examples': [
            {'code': 'let total;\nfor (let i = 0; i < 3; i++) {\n  total += i;\n}\nconsole.log(total);', 'answer': 'NaN', 'options': ['NaN', '6', 'undefined', '3'], 'explanation': 'total is undefined, and adding a number results in NaN.'},
            {'code': 'const person = {name: "Alex"};\nperson = {name: "Jamie"};\nconsole.log(person);', 'answer': 'TypeError is raised', 'options': ['TypeError is raised', 'Prints the new object', 'Prints the original object', 'Prints undefined'], 'explanation': 'A const binding cannot be reassigned.'},
            {'code': 'function foo() {\n  console.log(bar);\n  var bar = 5;\n}\nfoo();', 'answer': 'undefined', 'options': ['undefined', 'ReferenceError', '5', 'null'], 'explanation': 'var declarations are hoisted, but initialization happens later.'},
        ],
    },
    {
        'type': 'fill-blank',
        'examples': [
            {'code': 'const arr = [1, 2, 3];\nconst [first, ___] = arr;', 'answer': '...rest', 'options': ['...rest', 'second', 'rest', 'first'], 'explanation': 'Rest syntax collects remaining array values.'},
            {'code': 'const active = true;\nconst result = active ? "on" : ___;', 'answer': '"off"', 'options': ['"off"', '"on"', 'false', 'true'], 'explanation': 'The ternary operator chooses one of two values.'},
        ],
    },
    {
        'type': 'multiple-choice',
        'examples': [
            {'code': 'The === operator checks both value and type.', 'answer': 'True', 'options': ['True', 'False', 'Only in strict mode', 'Only for numbers'], 'explanation': '=== is strict equality in JavaScript.'},
            {'code': 'let is block-scoped.', 'answer': 'True', 'options': ['True', 'False', 'Only inside functions', 'Only in loops'], 'explanation': 'let is block-scoped and not hoisted like var.'},
        ],
    },
]

quotes = [
    'I can tell you exactly what this does.',
    'Small mistakes become big bugs; spot them.',
    'I love short Python puzzles.',
    'JavaScript quirks are my specialty.',
    'Think like the interpreter, not the programmer.',
    'Brackets, scopes, and operators — let’s go.',
    'One line can hide a lot of meaning.',
]

id_counter = 1

def add_examples(category, language, examples):
    global id_counter
    for ex in examples:
        questions.append({
            'id': id_counter,
            'category': category,
            'type': ex.get('type', ''),
            'language': language,
            'mascotQuote': quotes[id_counter % len(quotes)],
            'prompt': ex.get('prompt', '') or ex['code'].split('\n')[0],
            'codeSnippet': ex['code'],
            'options': ex['options'],
            'correctAnswer': ex['answer'],
            'explanation': ex['explanation'],
        })
        id_counter += 1

# Generate at least 50 Python questions and 50 JavaScript questions.
for _ in range(5):
    for t in python_questions:
        for ex in t['examples']:
            if len([q for q in questions if q['language'] == 'python']) >= 50:
                break
            q = ex.copy()
            q['type'] = t['type']
            add_examples('python', 'python', [q])
        if len([q for q in questions if q['language'] == 'python']) >= 50:
            break

for _ in range(5):
    for t in js_questions:
        for ex in t['examples']:
            if len([q for q in questions if q['language'] == 'javascript']) >= 50:
                break
            q = ex.copy()
            q['type'] = t['type']
            add_examples('javascript', 'javascript', [q])
        if len([q for q in questions if q['language'] == 'javascript']) >= 50:
            break

# Add a handful of other categories if already present in the file.
others = [
    {'category': 'react', 'type': 'multiple-choice', 'language': 'text', 'mascotQuote': quotes[id_counter % len(quotes)], 'prompt': 'Which hook lets you run side effects after a function component renders?', 'code': '', 'options': ['useEffect', 'useState', 'useMemo', 'useRef'], 'answer': 'useEffect', 'explanation': 'useEffect runs after render.'},
    {'category': 'cs', 'type': 'multiple-choice', 'language': 'text', 'mascotQuote': quotes[id_counter % len(quotes)], 'prompt': 'What is the time complexity of binary search on a sorted array of n elements?', 'code': '', 'options': ['O(log n)', 'O(n)', 'O(n log n)', 'O(1)'], 'answer': 'O(log n)', 'explanation': 'Binary search halves the search space each step.'},
    {'category': 'data-structures', 'type': 'guess-output', 'language': 'python', 'mascotQuote': quotes[id_counter % len(quotes)], 'prompt': 'What does this print?', 'code': 'stack = []\nstack.append(1)\nstack.append(2)\nstack.append(3)\nstack.pop()\nprint(stack)', 'options': ['[1, 2]', '[1, 2, 3]', '[2, 3]', '[3]'], 'answer': '[1, 2]', 'explanation': 'pop removes the last item.'},
]
for extra in others:
    questions.append({
        'id': id_counter,
        'category': extra['category'],
        'type': extra['type'],
        'language': extra['language'],
        'mascotQuote': extra['mascotQuote'],
        'prompt': extra['prompt'],
        'codeSnippet': extra['code'],
        'options': extra['options'],
        'correctAnswer': extra['answer'],
        'explanation': extra['explanation'],
    })
    id_counter += 1

js_count = len([q for q in questions if q['language'] == 'javascript'])
py_count = len([q for q in questions if q['language'] == 'python'])
print(f'Python questions: {py_count}, JavaScript questions: {js_count}')

out_lines = ['export const QUESTIONS = [']
for q in questions:
    out_lines.extend([
        '  {',
        f'    id: {q["id"]},',
        f'    category: {json.dumps(q["category"])},',
        f'    type: {json.dumps(q["type"])},',
        f'    language: {json.dumps(q["language"])},',
        f'    mascotQuote: {json.dumps(q["mascotQuote"])},',
        f'    prompt: {json.dumps(q["prompt"])},',
        f'    codeSnippet: {json.dumps(q["codeSnippet"])},',
        f'    options: {json.dumps(q["options"])},',
        f'    correctAnswer: {json.dumps(q["correctAnswer"])},',
        f'    explanation: {json.dumps(q["explanation"])},',
        '  },',
    ])
out_lines.append('];')
out_lines.append('')
out_lines.append('export const CATEGORY_META = {')
out_lines.append('  python: { label: \'Python\', color: \'#4B8BF5\' },')
out_lines.append('  javascript: { label: \'JavaScript\', color: \'#F2C744\' },')
out_lines.append('  react: { label: \'React\', color: \'#4DD8E8\' },')
out_lines.append('  cs: { label: \'CS Fundamentals\', color: \'#B084F5\' },')
out_lines.append('  \'data-structures\': { label: \'Data Structures\', color: \'#F5895D\' },')
out_lines.append('};')

out_path.write_text('\n'.join(out_lines), encoding='utf-8')
print('Wrote', len(questions), 'questions to', out_path)
