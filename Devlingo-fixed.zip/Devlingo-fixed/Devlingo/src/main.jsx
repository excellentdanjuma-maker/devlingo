import React from 'react';
import ReactDOM from 'react-dom/client';
import Devlingo from './App';
import './styles/app.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Devlingo />
  </React.StrictMode>
);
