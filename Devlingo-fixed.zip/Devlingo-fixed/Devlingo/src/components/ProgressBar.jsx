import React from 'react';

export function ProgressBar({ total, current, results }) {
  return (
    <div className="pq-progress">
      <div className="pq-progress-row">
        {Array.from({ length: total }).map((_, i) => {
          let state = 'upcoming';
          if (results[i] === true) state = 'correct';
          else if (results[i] === false) state = 'wrong';
          else if (i === current) state = 'current';
          return <div key={i} className={`pq-tick pq-tick--${state}`} />;
        })}
      </div>
      <div className="pq-progress-label">
        Question {Math.min(current + 1, total)} / {total}
      </div>
    </div>
  );
}
