import React from 'react';
import { Award, Flame, Sparkles, Target, UserCircle2 } from 'lucide-react';

export function ProfilePanel({ profile, onOpenSettings }) {
  const level = profile.xp >= 200 ? 'advanced' : profile.xp >= 100 ? 'intermediate' : 'beginner';

  return (
    <div className="pq-profile-panel">
      <div className="pq-card pq-card--wide">
        <div className="pq-profile-heading">
          <div className="pq-avatar pq-avatar--large">{profile.name?.[0] || 'D'}</div>
          <div>
            <p className="pq-eyebrow">Profile</p>
            <h2>{profile.name}</h2>
            <p className="pq-muted">{profile.goal}</p>
          </div>
        </div>

        <div className="pq-stat-grid">
          <div className="pq-stat-card">
            <Sparkles size={16} />
            <span>{profile.xp} XP</span>
          </div>
          <div className="pq-stat-card">
            <Flame size={16} />
            <span>{profile.streak}-day streak</span>
          </div>
          <div className="pq-stat-card">
            <Target size={16} />
            <span>{level} level</span>
          </div>
        </div>

        <div className="pq-achievement-list">
          {profile.achievements?.length ? profile.achievements.map((achievement) => (
            <div key={achievement.id} className="pq-achievement-item">
              <span className="pq-achievement-icon">{achievement.icon}</span>
              <div>
                <strong>{achievement.title}</strong>
                <p>{achievement.detail}</p>
              </div>
            </div>
          )) : (
            <div className="pq-empty-state">
              <Award size={18} />
              <span>Complete your first run to unlock achievements.</span>
            </div>
          )}
        </div>

        <button className="pq-btn pq-btn--ghost pq-btn--full" onClick={onOpenSettings}>
          <UserCircle2 size={16} />
          Open settings
        </button>
      </div>
    </div>
  );
}
