import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Sparkles, ShieldCheck, Trophy } from 'lucide-react';

const steps = [
  {
    title: 'Welcome to Devlingo',
    body: 'A calmer, smarter coding practice app that grows with your pace.',
    icon: Sparkles,
  },
  {
    title: 'Track progress',
    body: 'Daily streaks, XP, and shared achievements keep your momentum visible.',
    icon: Trophy,
  },
  {
    title: 'Stay secure',
    body: 'Sign in with Google or Apple to keep your profile and progress synced.',
    icon: ShieldCheck,
  },
];

export function OnboardingFlow({ profile, onComplete, onSignIn }) {
  const [step, setStep] = useState(0);
  const [goal, setGoal] = useState(profile.goal || 'Build confidence');

  const StepIcon = steps[step].icon;

  return (
    <div className="pq-onboarding">
      <div className="pq-card pq-card--wide">
        <div className="pq-onboarding-header">
          <div className="pq-onboarding-badge">
            <StepIcon size={18} />
          </div>
          <div>
            <p className="pq-eyebrow">Getting started</p>
            <h2>{steps[step].title}</h2>
          </div>
        </div>

        <p className="pq-onboarding-body">{steps[step].body}</p>

        {step === steps.length - 1 ? (
          <div className="pq-auth-stack">
            <label className="pq-input-group">
              <span>Focus goal</span>
              <input value={goal} onChange={(event) => setGoal(event.target.value)} />
            </label>
            <button className="pq-btn pq-btn--primary pq-btn--full" onClick={() => onComplete({ goal })}>
              Start learning
              <ArrowRight size={18} />
            </button>
            <button className="pq-btn pq-btn--ghost pq-btn--full" onClick={onSignIn}>
              Continue with Google / Apple
            </button>
          </div>
        ) : (
          <div className="pq-onboarding-actions">
            <button className="pq-btn pq-btn--ghost" onClick={() => setStep((value) => Math.min(value + 1, steps.length - 1))}>
              Next
              <ArrowRight size={18} />
            </button>
          </div>
        )}

        <div className="pq-step-dots">
          {steps.map((item, index) => (
            <span key={item.title} className={`pq-step-dot ${index <= step ? 'pq-step-dot--active' : ''}`} />
          ))}
        </div>
      </div>
    </div>
  );
}
