import React from 'react';
import { highlightLine } from '../utils/codeHighlighter';

export function CodeBlock({ code, language, blankValue, onBlankClick, answered }) {
  if (!code) return null;

  const lines = code.split('\n');
  const blankNode = (
    <button
      type="button"
      onClick={onBlankClick}
      disabled={answered}
      className={`pq-blank ${blankValue ? 'pq-blank--filled' : ''}`}
    >
      {blankValue || '___'}
    </button>
  );

  return (
    <div className="pq-codeblock">
      <div className="pq-codeblock-bar">
        <span className="pq-dot pq-dot--r" />
        <span className="pq-dot pq-dot--y" />
        <span className="pq-dot pq-dot--g" />
        <span className="pq-codeblock-lang">{language}</span>
      </div>
      <pre className="pq-codeblock-body">
        {lines.map((line, i) => (
          <div className="pq-code-line" key={i}>
            <span className="pq-line-no">{i + 1}</span>
            <code>{highlightLine(line, language, blankNode)}</code>
          </div>
        ))}
      </pre>
    </div>
  );
}
