import React from 'react';
import { RotateCcw, Trophy, Sparkles, Flame } from 'lucide-react';
import { CATEGORY_META } from '../data/questions';

export function ResultModal({ score, total, bestStreak, breakdown, onRestart, xpEarned, streak }) {
  const pct = Math.round((score / total) * 100);

  return (
    <div className="pq-modal-backdrop">
      <div className="pq-modal">
        <div className="pq-modal-trophy">
          <Trophy size={40} strokeWidth={2} />
        </div>
        <h2 className="pq-modal-title">Run complete</h2>
        <p className="pq-modal-sub">
          {pct >= 80
            ? 'Clean build — barely any errors.'
            : pct >= 50
            ? 'It compiles. Room to optimize.'
            : 'A rough build. Run it again to refactor.'}
        </p>

        <div className="pq-modal-stats">
          <div className="pq-modal-stat">
            <span className="pq-modal-stat-value">{score}/{total}</span>
            <span className="pq-modal-stat-label">Correct</span>
          </div>
          <div className="pq-modal-stat">
            <span className="pq-modal-stat-value">{pct}%</span>
            <span className="pq-modal-stat-label">Accuracy</span>
          </div>
          <div className="pq-modal-stat">
            <span className="pq-modal-stat-value">{bestStreak}</span>
            <span className="pq-modal-stat-label">Best streak</span>
          </div>
        </div>

        <div className="pq-reward-row">
          <div className="pq-reward-pill">
            <Sparkles size={16} />
            {xpEarned} XP earned
          </div>
          <div className="pq-reward-pill">
            <Flame size={16} />
            {streak} day streak
          </div>
        </div>

        <div className="pq-modal-breakdown">
          {Object.entries(breakdown).map(([cat, v]) => (
            <div key={cat} className="pq-modal-breakdown-row">
              <span className="pq-cat-dot" style={{ background: CATEGORY_META[cat].color }} />
              <span className="pq-modal-breakdown-label">{CATEGORY_META[cat].label}</span>
              <span className="pq-modal-breakdown-value">{v.correct}/{v.total}</span>
            </div>
          ))}
        </div>

        <button className="pq-btn pq-btn--primary pq-modal-btn" onClick={onRestart}>
          <RotateCcw size={18} />
          Run again
        </button>
      </div>
    </div>
  );
}
