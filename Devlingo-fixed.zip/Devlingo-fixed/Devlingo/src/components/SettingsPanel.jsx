import React from 'react';
import { Bell, MoonStar, Volume2, ShieldCheck } from 'lucide-react';

export function SettingsPanel({ profile, onToggleSetting, onSignOut }) {
  return (
    <div className="pq-settings-panel">
      <div className="pq-card pq-card--wide">
        <div className="pq-section-title">
          <ShieldCheck size={18} />
          <h2>Settings</h2>
        </div>

        <label className="pq-setting-row">
          <div>
            <strong>Notifications</strong>
            <p>Daily reminders keep your streak alive.</p>
          </div>
          <input type="checkbox" checked={profile.notificationsEnabled} onChange={() => onToggleSetting('notificationsEnabled')} />
        </label>

        <label className="pq-setting-row">
          <div>
            <strong>Sound effects</strong>
            <p>Celebrate progress with subtle feedback.</p>
          </div>
          <input type="checkbox" checked={profile.soundEnabled} onChange={() => onToggleSetting('soundEnabled')} />
        </label>

        <label className="pq-setting-row">
          <div>
            <strong>Theme preference</strong>
            <p>Switch between dark and light moods.</p>
          </div>
          <select value={profile.themePreference} onChange={(event) => onToggleSetting('themePreference', event.target.value)}>
            <option value="dark">Dark</option>
            <option value="light">Light</option>
          </select>
        </label>

        <div className="pq-settings-actions">
          <button className="pq-btn pq-btn--ghost" onClick={onSignOut}>Sign out</button>
        </div>
      </div>
    </div>
  );
}
