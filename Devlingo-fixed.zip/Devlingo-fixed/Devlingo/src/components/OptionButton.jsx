import React from 'react';
import { Check, X } from 'lucide-react';

export function OptionButton({ label, letter, state, onClick, disabled, compact }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`pq-option ${compact ? 'pq-option--compact' : ''} pq-option--${state}`}
    >
      {!compact && <span className="pq-option-letter">{letter}</span>}
      <span className="pq-option-text">{label}</span>
      {state === 'correct' && <Check size={18} strokeWidth={3} className="pq-option-icon" />}
      {state === 'wrong' && <X size={18} strokeWidth={3} className="pq-option-icon" />}
    </button>
  );
}
