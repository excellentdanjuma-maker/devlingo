import React from 'react';

export function AppSplash({ title = 'Excel Devs', subtitle = 'Building confidence, one line at a time.' }) {
  return (
    <div className="pq-splash" aria-hidden="true">
      <div className="pq-splash-orb" />
      <div className="pq-splash-content">
        <div className="pq-splash-badge">
          <img src="/app-logo.svg" alt="Devlingo logo" className="pq-splash-logo" />
        </div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
    </div>
  );
}
