import React from 'react';

export function MascotHeader({ quote, mood }) {
  return (
    <div className="pq-mascot-row">
      <div className={`pq-mascot pq-mascot--${mood}`}>
        <svg viewBox="0 0 64 64" width="52" height="52">
          <rect x="4" y="4" width="56" height="56" rx="16" fill="url(#mgrad)" />
          <defs>
            <linearGradient id="mgrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="var(--accent)" />
              <stop offset="100%" stopColor="var(--accent-2)" />
            </linearGradient>
          </defs>
          <text x="14" y="41" fontFamily="JetBrains Mono, monospace" fontSize="22" fontWeight="700" fill="#0B0E14">{'<'}</text>
          <text x="34" y="41" fontFamily="JetBrains Mono, monospace" fontSize="22" fontWeight="700" fill="#0B0E14">{'/'}</text>
          <text x="47" y="41" fontFamily="JetBrains Mono, monospace" fontSize="22" fontWeight="700" fill="#0B0E14">{'>'}</text>
        </svg>
      </div>
      <div className="pq-speech">
        <span>{quote}</span>
        <span className="pq-cursor">_</span>
      </div>
    </div>
  );
}
