import React, { useEffect, useMemo, useState } from 'react';
import {
  BookOpen,
  ChevronRight,
  Flame,
  Sparkles,
  Terminal,
  Bug,
  Code2,
  HelpCircle,
  Check,
  X,
  Settings2,
  UserCircle2,
  Trophy,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';
import { QUESTIONS, CATEGORY_META } from './data/questions';
import { ProgressBar } from './components/ProgressBar';
import { MascotHeader } from './components/MascotHeader';
import { CodeBlock } from './components/CodeBlock';
import { OptionButton } from './components/OptionButton';
import { ResultModal } from './components/ResultModal';
import { OnboardingFlow } from './components/OnboardingFlow';
import { ProfilePanel } from './components/ProfilePanel';
import { SettingsPanel } from './components/SettingsPanel';
import { AppSplash } from './components/AppSplash';
import { getInitialProfile, hydrateProfile, updateProfileForSession } from './utils/progression';
import { signInWithProvider, signOutAuth, subscribeToAuth } from './utils/firebase';

const TYPE_META = {
  'guess-output': { label: 'Guess the Output', icon: Terminal },
  'find-bug': { label: 'Find the Bug', icon: Bug },
  'fill-blank': { label: 'Fill in the Blank', icon: Code2 },
  'multiple-choice': { label: 'Quick Check', icon: HelpCircle },
};

function loadProfile() {
  if (typeof window === 'undefined') return getInitialProfile();
  try {
    const raw = window.localStorage.getItem('devlingo-profile');
    return hydrateProfile(raw ? JSON.parse(raw) : null);
  } catch {
    return getInitialProfile();
  }
}

export default function Devlingo() {
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [results, setResults] = useState({});
  const [finished, setFinished] = useState(false);
  const [pulseStreak, setPulseStreak] = useState(false);
  const [shakeWrong, setShakeWrong] = useState(false);
  const [view, setView] = useState('learn');
  const [profile, setProfile] = useState(loadProfile);
  const [authMessage, setAuthMessage] = useState('');
  const [authPending, setAuthPending] = useState(false);
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('devlingo-profile', JSON.stringify(profile));
    }
  }, [profile]);

  useEffect(() => {
    const timer = window.setTimeout(() => setShowSplash(false), 1400);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const unsubscribe = subscribeToAuth((user) => {
      if (!user) return;
      setProfile((current) => ({
        ...current,
        name: user.displayName || current.name,
        email: user.email || current.email,
        photoURL: user.photoURL || current.photoURL,
        authProvider: user.providerData?.[0]?.providerId || current.authProvider,
      }));
      setAuthMessage('Signed in successfully. Your progress stays synced.');
    });

    return unsubscribe;
  }, []);

  const q = QUESTIONS[index];
  const catMeta = CATEGORY_META[q.category];
  const TypeIcon = TYPE_META[q.type].icon;
  const isFillBlank = q.type === 'fill-blank';

  const breakdown = useMemo(() => {
    const map = {};
    QUESTIONS.forEach((question, questionIndex) => {
      if (!map[question.category]) {
        map[question.category] = { correct: 0, total: 0 };
      }
      map[question.category].total += 1;
      if (results[questionIndex] === true) {
        map[question.category].correct += 1;
      }
    });
    return map;
  }, [results]);

  const xpEarned = score + Math.max(0, streak) * 5 + 12;

  function pickOption(opt) {
    if (answered) return;
    setSelected(opt);
  }

  function checkAnswer() {
    if (!selected || answered) return;

    const isCorrect = selected === q.correctAnswer;
    setAnswered(true);
    setResults((previous) => ({ ...previous, [index]: isCorrect }));

    if (isCorrect) {
      setScore((current) => current + 10 + Math.min(streak, 5) * 2);
      setStreak((current) => {
        const next = current + 1;
        setBestStreak((best) => Math.max(best, next));
        if (next > 0 && next % 3 === 0) {
          setPulseStreak(true);
          setTimeout(() => setPulseStreak(false), 900);
        }
        return next;
      });
    } else {
      setStreak(0);
      setShakeWrong(true);
      setTimeout(() => setShakeWrong(false), 500);
    }
  }

  function next() {
    if (index + 1 >= QUESTIONS.length) {
      const updatedProfile = updateProfileForSession(profile, {
        score: score + 10 + Math.min(streak, 5) * 2,
        bestStreak: Math.max(bestStreak, streak + 1),
        completedSessions: 1,
      });
      setProfile(updatedProfile);
      setFinished(true);
      return;
    }

    setIndex((current) => current + 1);
    setSelected(null);
    setAnswered(false);
  }

  function restart() {
    setIndex(0);
    setSelected(null);
    setAnswered(false);
    setScore(0);
    setStreak(0);
    setBestStreak(0);
    setResults({});
    setFinished(false);
  }

  function handleOnboardingComplete({ goal }) {
    setProfile((current) => ({ ...current, goal, onboardingComplete: true }));
    setView('learn');
  }

  function handleSignIn(provider) {
    setAuthPending(true);
    setAuthMessage('');
    signInWithProvider(provider)
      .then((result) => {
        const user = result.user;
        setProfile((current) => ({
          ...current,
          name: user.displayName || current.name,
          email: user.email || current.email,
          photoURL: user.photoURL || current.photoURL,
          authProvider: user.providerData?.[0]?.providerId || current.authProvider,
          onboardingComplete: true,
        }));
        setAuthMessage(`Signed in with ${provider === 'apple' ? 'Apple' : 'Google'}.`);
        setView('profile');
      })
      .catch((error) => {
        setAuthMessage(error.message || 'Unable to sign in right now.');
      })
      .finally(() => setAuthPending(false));
  }

  function handleToggleSetting(key, value) {
    setProfile((current) => ({
      ...current,
      [key]: typeof value === 'undefined' ? !current[key] : value,
    }));
  }

  async function handleSignOut() {
    try {
      await signOutAuth();
      setProfile((current) => ({ ...current, authProvider: 'guest' }));
      setAuthMessage('Signed out. You can keep practicing as a guest.');
    } catch {
      setAuthMessage('Signing out failed.');
    }
  }

  const mood = !answered ? 'idle' : selected === q.correctAnswer ? 'happy' : 'oops';

  if (showSplash) {
    return <AppSplash />;
  }

  if (!profile.onboardingComplete) {
    return <OnboardingFlow profile={profile} onComplete={handleOnboardingComplete} onSignIn={() => handleSignIn('google')} />;
  }

  return (
    <div className={`pq-root ${profile.themePreference === 'light' ? 'pq-root--light' : ''}`}>
      <div className="pq-shell">
        <div className="pq-brand-row">
          <div className="pq-logo-slot" aria-label="App logo placeholder">
            <div className="pq-logo-image">
              <img src="/app-logo.svg" alt="Devlingo logo" />
            </div>
            <div className="pq-logo-caption">
              <div className="pq-brand-name">devlingo</div>
              <div className="pq-brand-subtitle">A polished coding practice studio for daily growth</div>
            </div>
          </div>
        </div>

        <div className="pq-hero-card">
          <div className="pq-hero-copy">
            <p className="pq-eyebrow">Welcome back</p>
            <h1>{profile.name}</h1>
            <p>{profile.goal}</p>
          </div>
          <div className="pq-hero-stats">
            <div className={`pq-stat pq-stat--streak ${pulseStreak ? 'pulse' : ''}`}>
              <Flame size={16} />
              {profile.streak || streak}-day streak
            </div>
            <div className="pq-stat pq-stat--score">
              <Sparkles size={16} />
              {profile.xp + score} XP
            </div>
          </div>
        </div>

        <div className="pq-nav">
          <button className={`pq-nav-btn ${view === 'learn' ? 'pq-nav-btn--active' : ''}`} onClick={() => setView('learn')}>
            <BookOpen size={16} />
            Learn
          </button>
          <button className={`pq-nav-btn ${view === 'profile' ? 'pq-nav-btn--active' : ''}`} onClick={() => setView('profile')}>
            <UserCircle2 size={16} />
            Profile
          </button>
          <button className={`pq-nav-btn ${view === 'settings' ? 'pq-nav-btn--active' : ''}`} onClick={() => setView('settings')}>
            <Settings2 size={16} />
            Settings
          </button>
        </div>

        {authMessage ? <div className="pq-status-banner">{authMessage}</div> : null}

        {view === 'learn' ? (
          <>
            <div className="pq-gradient-card">
              <div>
                <p className="pq-eyebrow">Today’s focus</p>
                <h2>Practice one concept, build a streak, and keep your momentum.</h2>
              </div>
              <div className="pq-bullets">
                <div className="pq-bullet"><ShieldCheck size={16} /> Sign in for a secure profile</div>
                <div className="pq-bullet"><Trophy size={16} /> Unlock achievements as you learn</div>
              </div>
            </div>

            <ProgressBar total={QUESTIONS.length} current={index} results={results} />
            <MascotHeader quote={q.mascotQuote} mood={mood} />

            <div className="pq-card">
              <div className="pq-tags">
                <span className="pq-tag pq-tag--cat" style={{ background: catMeta.color }}>
                  {catMeta.label}
                </span>
                <span className="pq-tag">
                  <TypeIcon size={12} />
                  {TYPE_META[q.type].label}
                </span>
              </div>

              <div className="pq-prompt">{q.prompt}</div>

              <CodeBlock
                code={q.codeSnippet}
                language={q.language}
                answered={answered}
                blankValue={selected}
                onBlankClick={() => {
                  if (!answered && isFillBlank) {
                    setSelected(q.options[0]);
                  }
                }}
              />

              <div className={`pq-options ${isFillBlank ? 'pq-options--chips' : ''} ${shakeWrong ? 'pq-shake' : ''}`}>
                {q.options.map((opt, i) => {
                  let state = 'default';
                  if (answered) {
                    if (opt === q.correctAnswer) state = 'correct';
                    else if (opt === selected) state = 'wrong';
                    else state = 'dim';
                  } else if (opt === selected) {
                    state = 'selected';
                  }

                  return (
                    <OptionButton
                      key={opt}
                      label={opt}
                      letter={String.fromCharCode(65 + i)}
                      state={state}
                      compact={isFillBlank}
                      disabled={answered}
                      onClick={() => pickOption(opt)}
                    />
                  );
                })}
              </div>

              {answered && (
                <div className={`pq-explain ${selected === q.correctAnswer ? 'pq-explain--correct' : 'pq-explain--wrong'}`}>
                  <div className="pq-explain-title">
                    {selected === q.correctAnswer ? (
                      <>
                        <Check size={15} strokeWidth={3} /> Correct
                      </>
                    ) : (
                      <>
                        <X size={15} strokeWidth={3} /> Not quite
                      </>
                    )}
                  </div>
                  <div className="pq-explain-body">{q.explanation}</div>
                </div>
              )}

              <div className="pq-actions">
                {!answered ? (
                  <button className="pq-btn pq-btn--primary" disabled={!selected} onClick={checkAnswer}>
                    Check answer
                  </button>
                ) : (
                  <button className="pq-btn pq-btn--continue" onClick={next}>
                    {index + 1 >= QUESTIONS.length ? 'See results' : 'Continue'}
                    <ChevronRight size={18} />
                  </button>
                )}
              </div>
            </div>
          </>
        ) : null}

        {view === 'profile' ? <ProfilePanel profile={profile} onOpenSettings={() => setView('settings')} /> : null}
        {view === 'settings' ? (
          <SettingsPanel
            profile={profile}
            onToggleSetting={handleToggleSetting}
            onSignOut={handleSignOut}
          />
        ) : null}
      </div>

      {finished && (
        <ResultModal
          score={score}
          total={QUESTIONS.length}
          bestStreak={bestStreak}
          breakdown={breakdown}
          onRestart={restart}
          xpEarned={xpEarned}
          streak={profile.streak || streak}
        />
      )}
    </div>
  );
}
