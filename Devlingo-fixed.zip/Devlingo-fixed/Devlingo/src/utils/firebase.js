import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  OAuthProvider,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
} from 'firebase/auth';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || '',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
};

let authInstance = null;

function getAuthInstance() {
  if (!firebaseConfig.apiKey || !firebaseConfig.projectId) {
    return null;
  }

  if (!authInstance) {
    const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
    authInstance = getAuth(app);
  }

  return authInstance;
}

export async function signInWithProvider(providerName) {
  const auth = getAuthInstance();

  if (!auth) {
    throw new Error('Firebase authentication is not configured yet. Add your web credentials to enable Google and Apple sign-in.');
  }

  const provider = providerName === 'apple' ? new OAuthProvider('apple.com') : new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  return signInWithPopup(auth, provider);
}

export async function signOutAuth() {
  const auth = getAuthInstance();
  if (!auth) return;
  await firebaseSignOut(auth);
}

export function subscribeToAuth(onChange) {
  const auth = getAuthInstance();
  if (!auth) return () => {};
  return onAuthStateChanged(auth, onChange);
}
