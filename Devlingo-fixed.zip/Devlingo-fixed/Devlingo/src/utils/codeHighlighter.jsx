const PY_KEYWORDS = [
  'def', 'return', 'if', 'else', 'elif', 'for', 'while', 'in', 'import', 'from',
  'class', 'print', 'True', 'False', 'None', 'and', 'or', 'not', 'pass', 'break',
  'continue', 'lambda', 'with', 'as', 'try', 'except', 'finally', 'raise', 'yield',
];

const JS_KEYWORDS = [
  'function', 'return', 'const', 'let', 'var', 'if', 'else', 'for', 'while', 'in',
  'of', 'import', 'from', 'export', 'class', 'new', 'this', 'true', 'false', 'null',
  'undefined', 'typeof', 'instanceof', 'try', 'catch', 'finally', 'throw', 'async', 'await',
  'default', 'extends', 'super', 'useState', 'useEffect',
];

export function buildTokenRegex(lang) {
  const kws = lang === 'python' ? PY_KEYWORDS : JS_KEYWORDS;
  const kwPattern = kws.map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');

  return new RegExp(
    `(${lang === 'python' ? '#.*' : '//.*'})` +
      `|('(?:[^'\\\\]|\\\\.)*'|"(?:[^"\\\\]|\\\\.)*"|` +
      "`(?:[^`\\\\]|\\\\.)*`)" +
      `|(\\b\\d+\\.?\\d*\\b)` +
      `|(___)` +
      `|(\\b(?:${kwPattern})\\b)` +
      `|(\\b[a-zA-Z_]\\w*(?=\\s*\\())`,
    'g'
  );
}

export function highlightLine(line, lang, blankNode) {
  if (!line) {
    return [<span key="empty">&nbsp;</span>];
  }

  if (lang === 'text') {
    return [line];
  }

  const regex = buildTokenRegex(lang);
  const pieces = [];
  let lastIndex = 0;
  let match;
  let key = 0;

  while ((match = regex.exec(line)) !== null) {
    if (match.index > lastIndex) {
      pieces.push(<span key={key++}>{line.slice(lastIndex, match.index)}</span>);
    }

    const [full, comment, str, num, blank, kw, fn] = match;

    if (blank) {
      pieces.push(<span key={key++}>{blankNode}</span>);
    } else if (comment) {
      pieces.push(<span key={key++} className="tok-comment">{full}</span>);
    } else if (str) {
      pieces.push(<span key={key++} className="tok-string">{full}</span>);
    } else if (num) {
      pieces.push(<span key={key++} className="tok-number">{full}</span>);
    } else if (kw) {
      pieces.push(<span key={key++} className="tok-keyword">{full}</span>);
    } else if (fn) {
      pieces.push(<span key={key++} className="tok-func">{full}</span>);
    }

    lastIndex = match.index + full.length;
  }

  if (lastIndex < line.length) {
    pieces.push(<span key={key++}>{line.slice(lastIndex)}</span>);
  }

  return pieces;
}
