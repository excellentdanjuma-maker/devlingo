export function todayKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function isYesterday(label, date = new Date()) {
  if (!label) return false;
  const current = new Date(date);
  const previous = new Date(label);
  previous.setHours(0, 0, 0, 0);
  current.setHours(0, 0, 0, 0);
  const diff = current.getTime() - previous.getTime();
  return diff === 24 * 60 * 60 * 1000;
}

export function getInitialProfile() {
  return {
    name: 'Learner',
    email: '',
    photoURL: '',
    goal: 'Build confidence',
    level: 'beginner',
    onboardingComplete: false,
    xp: 0,
    streak: 1,
    bestStreak: 1,
    lastActive: todayKey(),
    completedSessions: 0,
    achievements: [],
    authProvider: 'guest',
    notificationsEnabled: true,
    soundEnabled: true,
    themePreference: 'dark',
  };
}

export function hydrateProfile(raw) {
  const base = getInitialProfile();
  if (!raw) return base;
  return {
    ...base,
    ...raw,
    achievements: Array.isArray(raw.achievements) ? raw.achievements : [],
    completedSessions: Number(raw.completedSessions || 0),
    xp: Number(raw.xp || 0),
    streak: Number(raw.streak || 1),
    bestStreak: Number(raw.bestStreak || 1),
  };
}

export function updateProfileForSession(profile, { score, bestStreak, completedSessions = 1 }) {
  const today = todayKey();
  const lastActive = profile.lastActive || today;
  let streak = profile.streak || 1;

  if (lastActive !== today) {
    streak = isYesterday(lastActive) ? streak + 1 : 1;
  }

  const nextXp = (profile.xp || 0) + score + Math.max(0, streak) * 5 + completedSessions * 12;
  const nextBestStreak = Math.max(profile.bestStreak || 1, Math.max(streak, bestStreak || 1));
  const nextCompletedSessions = (profile.completedSessions || 0) + completedSessions;

  const achievements = unlockAchievements(profile.achievements || [], {
    xp: nextXp,
    streak,
    bestStreak: nextBestStreak,
    completedSessions: nextCompletedSessions,
    score,
  });

  return {
    ...profile,
    xp: nextXp,
    streak,
    bestStreak: nextBestStreak,
    lastActive: today,
    completedSessions: nextCompletedSessions,
    achievements,
  };
}

export function unlockAchievements(existing, { xp, streak, bestStreak, completedSessions, score }) {
  const unlocked = [...existing];
  const addAchievement = (achievement) => {
    if (!unlocked.some((item) => item.id === achievement.id)) {
      unlocked.push(achievement);
    }
  };

  if (completedSessions >= 1) {
    addAchievement({ id: 'first-lesson', title: 'First lesson', detail: 'Complete your first coding challenge.', icon: '🎯' });
  }
  if (xp >= 100) {
    addAchievement({ id: 'xp-100', title: 'Level up', detail: 'Earn 100 XP.', icon: '⚡' });
  }
  if (streak >= 3) {
    addAchievement({ id: 'streak-3', title: 'Steady streak', detail: 'Keep a 3-day streak alive.', icon: '🔥' });
  }
  if (bestStreak >= 5) {
    addAchievement({ id: 'streak-5', title: 'Momentum builder', detail: 'Reach a 5-question streak.', icon: '🚀' });
  }
  if (score >= 100) {
    addAchievement({ id: 'perfect-run', title: 'Perfect run', detail: 'Score 100 in a session.', icon: '🏅' });
  }

  return unlocked;
}
